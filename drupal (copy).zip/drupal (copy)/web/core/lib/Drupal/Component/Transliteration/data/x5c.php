<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'po', 'feng', 'zhuan', 'fu', 'she', 'ke', 'jiang', 'jiang', 'zhuan', 'wei', 'zun', 'xun', 'shu', 'dui', 'dao', 'xiao',
  0x10 => 'jie', 'shao', 'er', 'er', 'er', 'ga', 'jian', 'shu', 'chen', 'shang', 'shang', 'mo', 'ga', 'chang', 'liao', 'xian',
  0x20 => 'xian', 'kun', 'you', 'wang', 'you', 'liao', 'liao', 'yao', 'mang', 'wang', 'wang', 'wang', 'ga', 'yao', 'duo', 'kui',
  0x30 => 'zhong', 'jiu', 'gan', 'gu', 'gan', 'tui', 'gan', 'gan', 'shi', 'yin', 'chi', 'kao', 'ni', 'jin', 'wei', 'niao',
  0x40 => 'ju', 'pi', 'ceng', 'xi', 'bi', 'ju', 'jie', 'tian', 'qu', 'ti', 'jie', 'wu', 'diao', 'shi', 'shi', 'ping',
  0x50 => 'ji', 'xie', 'zhen', 'xie', 'ni', 'zhan', 'xi', 'wei', 'man', 'e', 'lou', 'ping', 'ti', 'fei', 'shu', 'xie',
  0x60 => 'tu', 'lu', 'lu', 'xi', 'ceng', 'lu', 'ju', 'xie', 'ju', 'jue', 'liao', 'jue', 'shu', 'xi', 'che', 'tun',
  0x70 => 'ni', 'shan', 'wa', 'xian', 'li', 'e', 'dao', 'hui', 'long', 'yi', 'qi', 'ren', 'wu', 'han', 'shen', 'yu',
  0x80 => 'chu', 'sui', 'qi', 'ren', 'yue', 'ban', 'yao', 'ang', 'ya', 'wu', 'jie', 'e', 'ji', 'qian', 'fen', 'wan',
  0x90 => 'qi', 'cen', 'qian', 'qi', 'cha', 'jie', 'qu', 'gang', 'xian', 'ao', 'lan', 'dao', 'ba', 'zuo', 'zuo', 'yang',
  0xA0 => 'ju', 'gang', 'ke', 'gou', 'xue', 'po', 'li', 'tiao', 'qu', 'yan', 'fu', 'xiu', 'jia', 'ling', 'tuo', 'pi',
  0xB0 => 'ao', 'dai', 'kuang', 'yue', 'qu', 'hu', 'po', 'min', 'an', 'tiao', 'ling', 'chi', 'ping', 'dong', 'han', 'kui',
  0xC0 => 'xiu', 'mao', 'tong', 'xue', 'yi', 'bian', 'he', 'ba', 'luo', 'e', 'fu', 'xun', 'die', 'lu', 'en', 'er',
  0xD0 => 'gai', 'quan', 'dong', 'yi', 'mu', 'shi', 'an', 'wei', 'huan', 'zhi', 'mi', 'li', 'ji', 'tong', 'wei', 'you',
  0xE0 => 'gu', 'xia', 'li', 'yao', 'jiao', 'zheng', 'luan', 'jiao', 'e', 'e', 'yu', 'xie', 'bu', 'qiao', 'qun', 'feng',
  0xF0 => 'feng', 'nao', 'li', 'you', 'xian', 'hong', 'dao', 'shen', 'cheng', 'tu', 'geng', 'jun', 'hao', 'xia', 'yin', 'yu',
];
